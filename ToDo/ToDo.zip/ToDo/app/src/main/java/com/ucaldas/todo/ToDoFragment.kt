package com.ucaldas.todo

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment


class ToDoFragment : Fragment(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

val myFragment: View=inflater.inflate(R.layout.fragment_to_do, container, false)
        val detail1: Button= myFragment.findViewById(R.id.btn_detail1)
        val detail2: Button= myFragment.findViewById(R.id.btn_detail2)
        val detail3: Button= myFragment.findViewById(R.id.btn_detail3)

        detail1.setOnClickListener(View.OnClickListener {
            val datos = Bundle()
            datos.putString("tarea", resources.getString(R.string.txt_tarea_1))
            datos.putString("hora","10:00")
            datos.putString("lugar","kwik-mart")
            activity?.getSupportFragmentManager()?.beginTransaction()
                ?.setReorderingAllowed(true)
                ?.replace(R.id.myFContView, DetailFragment::class.java, datos, "detail")
                ?.addToBackStack("")
                ?.commit()
        })



        detail2.setOnClickListener(View.OnClickListener {
            val datos = Bundle()
            datos.putString("tarea", resources.getString(R.string.txt_tarea_2))
            datos.putString("hora","08:01")
            datos.putString("lugar","Taller")
            activity?.getSupportFragmentManager()?.beginTransaction()
                ?.setReorderingAllowed(true)
                ?.replace(R.id.myFContView, DetailFragment::class.java, datos, "detail")
                ?.addToBackStack("")
                ?.commit()
        })



        detail3.setOnClickListener(View.OnClickListener {
            val datos = Bundle()
            datos.putString("tarea", resources.getString(R.string.txt_tarea_3))
            datos.putString("hora","20:10")
            datos.putString("lugar","Laundrymat")
            activity?.getSupportFragmentManager()?.beginTransaction()
                ?.setReorderingAllowed(true)
                ?.replace(R.id.myFContView, DetailFragment::class.java, datos, "detail")
                ?.addToBackStack("")
                ?.commit()
        })




        return myFragment
    }


}
