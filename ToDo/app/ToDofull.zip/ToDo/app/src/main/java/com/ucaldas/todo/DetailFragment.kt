package com.ucaldas.todo

import android.os.Bundle
import androidx.fragment.app.Fragment

import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class DetailFragment :Fragment(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val fragmento =inflater.inflate(R.layout.fragment_detail, container, false)

        val task= requireArguments().getString("tarea")
        val hour= requireArguments().getString("hora")
        val place= requireArguments().getString("lugar")

        val textViewTask: TextView=fragmento.findViewById(R.id.textViewTarea)
        val textViewHour: TextView=fragmento.findViewById(R.id.textViewHora)
        val textViewPlace: TextView=fragmento.findViewById(R.id.textViewLugar)
        
        textViewTask.text =task
        textViewHour.text =hour
        textViewPlace.text =place


        return fragmento;
    }


}
