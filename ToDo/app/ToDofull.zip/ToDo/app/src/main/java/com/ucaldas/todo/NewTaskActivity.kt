package com.ucaldas.todo

import android.app.Activity
import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

import com.ucaldas.todo.room_database.ClsToDo
import com.ucaldas.todo.room_database.ClsToDoDatabase
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking


class NewTaskActivity: AppCompatActivity() {

    lateinit var editTextTitle: EditText
    lateinit var editTextTime: EditText
    lateinit var editTextPlace: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_task)
        editTextTitle = findViewById(R.id.myEditTextTitle)
        editTextTime = findViewById(R.id.myEditTextTime)
        editTextPlace = findViewById(R.id.myEditTextPlace)
    }

    fun myFunOnSave(view: View){
        val myDB = ClsToDoDatabase.getDatabase(this)
        val valdbFirebase = FirebaseFirestore.getInstance()




        val myIntfToDoDAO = myDB.myFunTodoDao()
        val myTask = ClsToDo(0, editTextTitle.text.toString(), editTextTime.text.toString(), editTextPlace.text.toString())

        runBlocking {
            launch {
                val myResult = myIntfToDoDAO.insertTask(myTask)
                if(myResult!=-1L){









                    valdbFirebase.collection("myCollectToDo").document(myResult.toString()).set(
                        hashMapOf("title" to editTextTitle.text.toString(),
                            "time" to editTextTime.text.toString(),
                            "place" to editTextPlace.text.toString()
                        ))
                    setResult(Activity.RESULT_OK) // informa q todo salio al pelo
                    finish()
                }
            }
        }

    }
}
